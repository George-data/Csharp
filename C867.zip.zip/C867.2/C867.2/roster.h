//
// Created by Anthony Mark George on 2/21/2021
// Class declarations
//
//Rubric: B
//Rubric: E
//
#ifndef ROSTER_H
#define ROSTER_H

#include "student.h"
#include <cstring>
#include <string>

//E
class Roster {
   public:
	   int currentArraySize = 0;
	   const static int MAX_CAPACITY = 5;
	   Student* classRosterArray[MAX_CAPACITY];
	   
	   //Deconstructor
	   ~Roster();

	   //Accessors (i.e. getters)
	   void printAll();
	   void printAverageDaysInCourse(string studentID);
	   void printInvalidEmails();
	   void printByDegreeProgram(DegreeProgram degreeProgram);

	   //Mutators (i.e. setters)
	   void parse(string row);
	   void add (string studentId, 
				 string firstName,
				 string lastName,
				 string emailAddress,
				 int age,
				 int daysInCourse1, int daysInCourse2, int daysInCourse3,							//Array
				 DegreeProgram degreeProgram);
	   void remove(string studentId);
};

#endif