//
// Created by Anthony Mark George on 2/21/2021
// Enumerator class
//
//Rubric: B
//
#ifndef DEGREE_H
#define DEGREE_H

enum DegreeProgram {SECURITY, NETWORK, SOFTWARE};																//Rubric: C


#endif