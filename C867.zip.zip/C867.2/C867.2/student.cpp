//
// Created by Anthony Mark George on 2/21/2021
// Class definitions
//
//Rubric: B
//Rubric: D
//
#include <iostream>
#include <string>
#include "student.h"
using namespace std;

//Constructor
Student::Student(string ID, string first, string last, string email, int age, int days[3], DegreeProgram degree) {
	setStudentId(ID);
	setFirstName(first);
	setLastName(last);
	setEmailAddress(email);
	setAge(age);
	setDaysInCourse(days);
	setDegreeProgram(degree);
};

//Destructor
Student::~Student() {};

//Accessors (i.e. getters)
string Student::getStudentId() const {
	return studentId;
};
string Student::getFirstName() const {
	return firstName;
};
string Student::getLastName() const {
	return lastName;
};
string Student::getEmailAddress() const {
	return emailAddress;
};
int Student::getAge() const {
	return age;
};
const int* Student::getDaysInCourse() const {
	return daysInCourse;
};
DegreeProgram Student::getDegreeProgram() {
	return degreeProgram;
};
void Student::print() {
																	//Change enum index into degree title
	string degree;

	if (getDegreeProgram() == 0) {
		degree = "SECURITY";
	}
	else if (getDegreeProgram() == 1) {
		degree = "NETWORK";
	}
	else if (getDegreeProgram() == 2) {
		degree = "SOFTWARE";
	}
	else {
		degree = "ERROR - NULL";
	}			

	cout <<							 getStudentId() << "\t";
	cout << "First Name: "		  << getFirstName() << "\t";
	cout << "Last Name: "		  << getLastName() << "\t";
	cout << "Age: "				  << getAge() << "\t";
	cout << "daysInCourse: {"	  << getDaysInCourse()[0] << ", " << getDaysInCourse()[1] << ", " << getDaysInCourse()[2];
	cout << "} Degree Program: "  << degree << endl;
};

//Mutators (i.e. setters)
void Student::setStudentId(string ID) {
	studentId = ID;
};
void Student::setFirstName(string first) {
	firstName = first;
};
void Student::setLastName(string last) {
	lastName = last;
}
void Student::setEmailAddress(string email) {
	emailAddress = email;
};
void Student::setAge(int age) {
	this->age = age;
};
void Student::setDaysInCourse(int* days) {
	for (int i = 0; i < 3; ++i) {
		daysInCourse[i] = days[i];
	}
};
void Student::setDegreeProgram(DegreeProgram degree) {
	degreeProgram = degree;
};
