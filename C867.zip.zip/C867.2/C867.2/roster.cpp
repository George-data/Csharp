//
// Created by Anthony Mark George on 2/21/2021
// Class definitions
//
//Rubric: B
//Rubric: E
//
#include <iostream>
#include <string>
#include <cstring>
#include "roster.h"
#include "student.h"
using namespace std;

//Accessors (i.e. getters)
void Roster::printAll() {		

	cout << "Current roster:" << endl;

	for (int i = 0; i < MAX_CAPACITY; ++i) {
		if (classRosterArray[i] != nullptr) {
			classRosterArray[i]->print();
		}
	}
	cout << endl;
};

void Roster::printAverageDaysInCourse(string studentID) {

	for (int i = 0; i < MAX_CAPACITY; ++i) {

		if (classRosterArray[i] != nullptr && classRosterArray[i]->getStudentId() == studentID) {							//If statement was created after remove function created, checking for nullptr not needed for this course
			const int* days = classRosterArray[i]->getDaysInCourse();
			int average = (days[0] + days[1] + days[2]) / 3;
			cout << "Student " << studentID << " - " << average << " days" << endl;
		}
	}
};

void Roster::printInvalidEmails() {

	cout << "Displaying invalid Emails in current roster:" << endl;

	for (int i = 0; i < MAX_CAPACITY; ++i) {

		bool inValid = true;
		string email = classRosterArray[i]->getEmailAddress();																//If in the future this function is called after "remove" function, add if statement to avoid nullptr
																																		
		if (email.find('@') == string::npos || (email.find('.') == string::npos || (email.find(' ') != string::npos))) {
					inValid = false;
		}
			if (!inValid) {
				if (email.find('@') == string::npos) {
					cout << classRosterArray[i]->getStudentId() << ": " << email << " - \"@\" missing." << endl;
				}
				if (email.find('.') == string::npos) {
					cout << classRosterArray[i]->getStudentId() << ": " << email << " - \".\" missing." << endl;
				}
				if (email.find(' ') != string::npos) {
					cout << classRosterArray[i]->getStudentId() << ": " << email << " - spaces are not allowed." << endl;
				}
			}
	}
	cout << endl;
};


void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {

	for (int i = 0; i < MAX_CAPACITY; i++) {
		if (classRosterArray[i] != nullptr) {																				//If statement was created after remove function created, checking for nullptr not needed for this course
			if (classRosterArray[i]->getDegreeProgram() == degreeProgram) {
				classRosterArray[i]->print();
			}
		}
	}
	cout << endl;
};

//Mutators (i.e. setters)
void Roster::parse(string row) {

	string dataItem[9];
	int numVar = 0;
	DegreeProgram degreeProgram;

	while (numVar < 9) {
		unsigned rhs = row.find(',');
		dataItem[numVar] = row.substr(0, rhs);					//ID
		++numVar;

		unsigned lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//First
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Last
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Email
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Age
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Days(1)
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Days(2)
		++numVar;

		lhs = rhs + 1;
		rhs = row.find(',', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Days(3)
		++numVar;

		lhs = rhs + 1;
		rhs = row.find('\0', lhs);
		dataItem[numVar] = row.substr(lhs, rhs - lhs);			//Degree
		++numVar;
	}

	if (dataItem[8] == "SECURITY") {							//Assign string to enumerator
		degreeProgram = SECURITY;
	}
	else if (dataItem[8] == "NETWORK") {
		degreeProgram = NETWORK;
	}
	else if (dataItem[8] == "SOFTWARE") {
		degreeProgram = SOFTWARE;
	}
	else {
		cout << "ERROR degree program";							//FIX needed if called
	}

	add(dataItem[0], dataItem[1], dataItem[2], dataItem[3], stoi(dataItem[4]), stoi(dataItem[5]), stoi(dataItem[6]), stoi(dataItem[7]), degreeProgram);

};

void Roster::add(string studentId, string firstName, string lastName,
	string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeProgram) {

	int courseDays[3] = { daysInCourse1, daysInCourse2, daysInCourse3 };
	classRosterArray[currentArraySize++] = new Student(studentId, firstName, lastName, emailAddress, age, courseDays, degreeProgram);
};

void Roster::remove(string studentID) {

	bool inRoster = false;
	for (int i = 0; i < MAX_CAPACITY; ++i) {
		if (classRosterArray[i] != nullptr && classRosterArray[i]->getStudentId() == studentID) {
			classRosterArray[i] = nullptr;
			inRoster = true;
			--currentArraySize;
			break;
		}
	}
	if (inRoster == false) {
		cout << "ERROR: Student ID: " << studentID << " is not in current roster." << endl;
	}
	else {
		cout << "Removed: " << studentID << " from current Roster." << endl;
	}
	cout << endl;
};

//Deconstructor
Roster::~Roster() {
	for (int i = 0; i < MAX_CAPACITY; ++i) {
		delete classRosterArray[i];
	}
};