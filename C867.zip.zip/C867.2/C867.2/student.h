//
// Created by Anthony Mark George on 2/21/2021
// Class declarations
//
//Rubric: B
//Rubric: D
//
#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include "degree.h"
using namespace std;

//D
class Student {
   public:
	   //Constructor
	   Student(string, string, string, string, int, int days[3], DegreeProgram);

	   //Destructor
	   ~Student();

	   //Accessors (i.e. getters)
	   string        getStudentId() const;
	   string        getFirstName() const;
	   string        getLastName() const;
	   string        getEmailAddress() const;
	   int           getAge() const;
	   const int    *getDaysInCourse() const;
	   DegreeProgram getDegreeProgram();
	   void          print();

	   //Mutators (i.e. setters)
	   void setStudentId(string);
	   void setFirstName(string);
	   void setLastName(string);
	   void setEmailAddress(string);
	   void setAge(int);
	   void setDaysInCourse(int*);
	   void setDegreeProgram(DegreeProgram);

   private:
	   string studentId;
	   string firstName;
	   string lastName;
	   string emailAddress;
	   int age;
	   int daysInCourse[3];
	   DegreeProgram degreeProgram;
};

#endif